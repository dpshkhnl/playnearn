<?php

$link=mysqli_connect("localhost","wpwalaco_nostra", "9575832359@1","wpwalaco_nostra");

if($link){
	//echo "Connected";
} else {
	echo "Error";
}
?>